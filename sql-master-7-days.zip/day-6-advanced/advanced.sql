-- Advanced SQL
CREATE INDEX idx_salary ON employees(salary);

CREATE VIEW high_salary_employees AS
SELECT name, salary
FROM employees
WHERE salary > 40000;
