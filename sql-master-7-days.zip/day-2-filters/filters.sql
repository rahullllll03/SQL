-- Filtering & Sorting
SELECT * FROM employees WHERE department = 'IT';
SELECT * FROM employees WHERE salary > 40000;
SELECT * FROM employees ORDER BY salary DESC;
