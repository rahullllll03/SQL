-- Employee Salary Analysis
SELECT department, COUNT(*) AS total_employees
FROM employees
GROUP BY department;

SELECT department, MAX(salary)
FROM employees
GROUP BY department;
