-- Aggregate Functions
SELECT COUNT(*) FROM employees;

SELECT department, AVG(salary)
FROM employees
GROUP BY department;

SELECT department, SUM(salary)
FROM employees
GROUP BY department;
