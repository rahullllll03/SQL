# Day 4 – Aggregates
- COUNT, SUM, AVG
- GROUP BY