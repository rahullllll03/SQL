# Day 6 – Optimization
- Indexes
- Views