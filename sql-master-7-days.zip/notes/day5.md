# Day 5 – Subqueries
- Nested queries