# Day 1 – SQL Basics
- SQL fundamentals
- CREATE, INSERT, SELECT