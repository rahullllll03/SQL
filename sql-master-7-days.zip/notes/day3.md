# Day 3 – Joins
- INNER JOIN
- LEFT JOIN