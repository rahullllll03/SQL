-- SQL Basics
CREATE TABLE employees (
  emp_id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  department VARCHAR(50),
  salary INT,
  joining_date DATE
);

INSERT INTO employees (name, department, salary, joining_date)
VALUES
('Rahul', 'IT', 45000, '2024-01-10'),
('Amit', 'HR', 30000, '2023-06-15'),
('Sneha', 'Finance', 50000, '2022-09-01');
